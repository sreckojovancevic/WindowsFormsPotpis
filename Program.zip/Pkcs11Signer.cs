﻿using System;
using System.IO;
using System.Windows.Forms;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using Org.BouncyCastle.X509;
using iText.Kernel.Pdf;
using iText.Signatures;
using iText.IO.Image;
using iText.Kernel.Geom;
using System.Linq;
using Path = System.IO.Path;

namespace WindowsFormsPotpis;

public class Pkcs11Signer
{
    public void SignPdfWithPkcs11 (string inputPdfPath, string pkcs11LibPath, string pin, string outputPdfPath, TextBox txtLog, bool includeTimestamp, iText.Kernel.Geom.Rectangle signatureRect)
    {
        try
        {
            using (IPkcs11Library pkcs11Library = new Pkcs11InteropFactories().Pkcs11LibraryFactory.LoadPkcs11Library(
                new Pkcs11InteropFactories(), pkcs11LibPath, AppType.MultiThreaded))
            {
                List<ISlot> slots = pkcs11Library.GetSlotList(SlotsType.WithTokenPresent);
                if (slots.Count == 0)
                {
                    txtLog.AppendText("❌ Nema dostupnih smart kartica.\n");
                    return;
                }

                using (ISession session = slots[0].OpenSession(SessionType.ReadWrite))
                {
                    session.Login(CKU.CKU_USER, pin);
                    txtLog.AppendText("✅ PIN prihvaćen, prijavljen na smart karticu.\n");

                    // Dobijanje sertifikata sa smart kartice
                    var certificateObjects = session.FindAllObjects(new List<IObjectAttribute>
                    {
                        session.Factories.ObjectAttributeFactory.Create(CKA.CKA_CLASS, CKO.CKO_CERTIFICATE)
                    });

                    if (certificateObjects.Count == 0)
                    {
                        txtLog.AppendText("❌ Nema dostupnih sertifikata na kartici.\n");
                        return;
                    }

                    // Uzimanje prvog sertifikata
                    byte[] certBytes = session.GetAttributeValue(certificateObjects[0], new List<CKA> { CKA.CKA_VALUE })[0].GetValueAsByteArray();
                    X509CertificateParser parser = new X509CertificateParser();
                    Org.BouncyCastle.X509.X509Certificate cert = parser.ReadCertificate(certBytes);

                    // Dobijanje privatnog ključa
                    var privateKeyObjects = session.FindAllObjects(new List<IObjectAttribute>
                    {
                        session.Factories.ObjectAttributeFactory.Create(CKA.CKA_CLASS, CKO.CKO_PRIVATE_KEY)
                    });

                    if (privateKeyObjects.Count == 0)
                    {
                        txtLog.AppendText("❌ Privatni ključ nije pronađen na smart kartici.\n");
                        return;
                    }

                    IObjectHandle privateKey = privateKeyObjects.First();

                    // ✅ Dodaj mehanizam (ovde je ispravljena greška!)
                    IMechanism mechanism = session.Factories.MechanismFactory.Create(CKM.CKM_RSA_PKCS);

                    using (var reader = new PdfReader(inputPdfPath))
                    using (var output = new FileStream(outputPdfPath, FileMode.Create))
                    {
                        PdfSigner signer = new PdfSigner(reader, output, new StampingProperties());

                        // ✅ Dodavanje ručnog potpisa
                        HandwrittenSignatureAdder.AddSignature(inputPdfPath, outputPdfPath, outputPdfPath, signatureRect);

                        IExternalSignature externalSignature = new Pkcs11Signature(session, privateKey, mechanism);
                        IExternalDigest digest = new BouncyCastleDigest();

                        signer.SignDetached(
                            digest,
                            externalSignature,
                            new[] { new iText.Bouncycastle.X509.X509CertificateBC(cert) },
                            null, null, null, 0,
                            PdfSigner.CryptoStandard.CADES);

                        txtLog.AppendText($"✅ PDF uspešno potpisan: {outputPdfPath}\n");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            txtLog.AppendText($"❌ Greška pri potpisivanju: {ex.Message}\n");
        }
    }
}
