﻿using System;
using iText.Kernel.Geom;
using iText.Forms.Fields.Properties;
using iText.Forms.Form.Element;
using iText.Signatures;

namespace WindowsFormsPotpis;

public static class SignatureAppearanceBuilder
{
    public static void BuildSignatureAppearance(SignerProperties signerProperties, string signatureSubjectName)
    {

        // ✅ Dodavanje teksta u potpis
        SignedAppearanceText signedText = new SignedAppearanceText()
     .SetSignedBy("User")
     .SetReasonLine("Dokument potpisan za verifikaciju")
     .SetLocationLine("Belgrade, Serbia")
     .SetSignDate(DateTime.Now);

        SignatureFieldAppearance appearance = new SignatureFieldAppearance("SignatureField");
        appearance.SetContent("", signedText);


        // ✅ Podešavanje lokacije potpisa
        iText.Kernel.Geom.Rectangle rect = new (36, 50, 200, 100);
        signerProperties.SetPageRect(rect);
        signerProperties.SetPageNumber(1);
        signerProperties.SetSignatureAppearance(appearance);
    }
}
