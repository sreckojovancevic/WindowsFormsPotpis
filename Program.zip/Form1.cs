﻿using System;
using System.Collections.Generic;
using System.IO; // For file handling
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using iText.Kernel.Pdf;
using iText.Signatures;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using Newtonsoft.Json;
using System.Security.Cryptography;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Element;
using iText.IO.Image;
using iText.Kernel.Geom; // For iText Rectangle
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Xobject;
using iText.Kernel.Font;
using iText.IO.Font.Constants;

namespace WindowsFormsPotpis;

public partial class Form1 : Form
{
    private string? selectedPdfFile = null;
    private string? selectedPkcs11Lib;
    private string? selectedSignatureImage = null;
    private List<IObjectHandle> availableCertificates = new List<IObjectHandle>();
    private iText.Kernel.Geom.Rectangle signatureRect = new iText.Kernel.Geom.Rectangle(150, 100, 300, 120); // Default position

    private Pkcs11Signer pkcs11Signer;
    private WindowsStoreSigner windowsStoreSigner;

    public Form1()
    {
        InitializeComponent();
        LoadAvailablePkcs11Libs();
        pkcs11Signer = new Pkcs11Signer();
        windowsStoreSigner = new WindowsStoreSigner();
    }

    private void LoadAvailablePkcs11Libs()
    {
        cbPkcs11Libs.Items.Clear();
        cbPkcs11Libs.Items.Add(@"C:\Program Files\MUP RS\Celik\netsetpkcs11_x64.dll");
        cbPkcs11Libs.SelectedIndex = 0;
    }

    private void LoadCertificates()

    {

        cbCertificates.Items.Clear();

        X509Store store = new X509Store(StoreName.My, StoreLocation.CurrentUser);

        store.Open(OpenFlags.ReadOnly);


        foreach (var cert in store.Certificates)

        {

            cbCertificates.Items.Add(cert);

        }


        store.Close();

    }


    private void btnRefreshCertificates_Click(object sender, EventArgs e)
    {
        LoadCertificates(); // Call the method to load certificates
        txtLog.AppendText("🔄 Certificates refreshed.\n");
    }

    private void cbPkcs11Libs_SelectedIndexChanged(object sender, EventArgs e)
    {
        selectedPkcs11Lib = cbPkcs11Libs.SelectedItem.ToString();
        txtLog.AppendText($"🔹 Izabrana PKCS#11 biblioteka: {selectedPkcs11Lib}\n");
    }

    private void cbCertificates_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (cbCertificates.SelectedItem is X509Certificate2 cert)
        {
            txtLog.AppendText($"🔹 Izabran sertifikat: {cert.Subject}\n");
        }
    }

    private void btnChooseFile_Click(object sender, EventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "PDF files (*.pdf)|*.pdf",
            Title = "Odaberi PDF fajl za potpisivanje"
        };

        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            selectedPdfFile = openFileDialog.FileName;
            txtSelectedFile.Text = selectedPdfFile;
        }
    }

    private void btnChooseSignature_Click(object sender, EventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg",
            Title = "Odaberite sliku ručnog potpisa"
        };

        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            selectedSignatureImage = openFileDialog.FileName;
            txtLog.AppendText("✔ Odabrana slika potpisa: " + selectedSignatureImage + "\n");

            // Show preview for positioning the signature
            SignaturePreviewForm previewForm = new SignaturePreviewForm(selectedSignatureImage);
            if (previewForm.ShowDialog() == DialogResult.OK)
            {
                // ✅ Convert System.Drawing.Rectangle to iText.Kernel.Geom.Rectangle
                signatureRect = new iText.Kernel.Geom.Rectangle(
                    previewForm.SelectedRectangle.X,
                    previewForm.SelectedRectangle.Y,
                    previewForm.SelectedRectangle.Width,
                    previewForm.SelectedRectangle.Height
                );

                txtLog.AppendText("✔ Pozicija potpisa podešena.\n");
            }
        }
    }

    private void btnSign_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(selectedPdfFile))
        {
            txtLog.AppendText("❌ Morate izabrati PDF fajl!\n");
            return;
        }

        if (string.IsNullOrEmpty(selectedSignatureImage))
        {
            txtLog.AppendText("❌ Morate odabrati sliku ručnog potpisa!\n");
            return;
        }

        string outputPdf = System.IO.Path.Combine(
            System.IO.Path.GetDirectoryName(selectedPdfFile),
            "Signed_" + System.IO.Path.GetFileName(selectedPdfFile)
        );

        if (cbCertificates.SelectedItem is X509Certificate2 selectedCert)
        {
            string pin = string.Empty;

            // Proveri da li je sertifikat sa smart kartice
            if (selectedCert.HasPrivateKey && selectedCert.PrivateKey is RSACryptoServiceProvider)
            {
                if (chkUsePkcs11.Checked) // Korisnik je odabrao da unosi PIN preko PKCS#11
                {
                    if (!PKCS11Authenticator.AuthenticateWithPkcs11(selectedPkcs11Lib, out pin))
                    {
                        txtLog.AppendText("❌ Autentifikacija nije uspela.\n");
                        return;
                    }
                }
            }

            // Nastavi sa potpisivanjem koristeći Windows Crypto API
            windowsStoreSigner.SignPdf(selectedPdfFile, selectedCert, outputPdf, txtLog, chkTimestamp.Checked, signatureRect);
        }
    }


    private string GetPinFromUser()
    {
        using (PinPromptForm pinForm = new PinPromptForm())
        {
            return pinForm.ShowDialog() == DialogResult.OK ? pinForm.EnteredPin : string.Empty;
        }
    }

    
    private void Form1_Load(object sender, EventArgs e)
    {
        txtLog.AppendText("📂 Application Loaded.\n");
    }

    private void btnSavePath_Click(object sender, EventArgs e)
    {
        txtLog.AppendText("📌 Path Saved.\n");
    }

    private void btnRefreshPkcs11Libs_Click(object sender, EventArgs e)
    {
        LoadAvailablePkcs11Libs();
        txtLog.AppendText("🔄 PKCS#11 Libraries Refreshed.\n");
    }

    private void btnChoosePkcs11Lib_Click(object sender, EventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "PKCS#11 Libraries (*.dll)|*.dll",
            Title = "Select PKCS#11 Library"
        };

        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            selectedPkcs11Lib = openFileDialog.FileName;
            txtPkcs11LibPath.Text = selectedPkcs11Lib;
        }
    }
}
