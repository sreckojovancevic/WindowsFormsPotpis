﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace WindowsFormsPotpis;
public class SignaturePreviewForm : Form
{
    private PictureBox pictureBox;
    private Button btnOk;
    private Rectangle selectedRectangle;

    public Rectangle SelectedRectangle => selectedRectangle;

    public SignaturePreviewForm(string imagePath)
    {
        InitializeComponent(imagePath);
    }

    private void InitializeComponent(string imagePath)
    {
        this.pictureBox = new PictureBox();
        this.btnOk = new Button();

        pictureBox.Image = Image.FromFile(imagePath);
        pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
        pictureBox.Dock = DockStyle.Fill;
        pictureBox.MouseClick += PictureBox_MouseClick;

        btnOk.Text = "OK";
        btnOk.Dock = DockStyle.Bottom;
        btnOk.Click += BtnOk_Click;

        this.Controls.Add(pictureBox);
        this.Controls.Add(btnOk);
        this.Text = "Set Signature Position";
        this.Size = new System.Drawing.Size(400, 300);
    }

    private void PictureBox_MouseClick(object sender, MouseEventArgs e)
    {
        selectedRectangle = new Rectangle(e.X, e.Y, 100, 50);
        MessageBox.Show($"Signature position set at: {selectedRectangle.X}, {selectedRectangle.Y}");
    }

    private void BtnOk_Click(object sender, EventArgs e)
    {
        this.DialogResult = DialogResult.OK;
        this.Close();
    }
}
