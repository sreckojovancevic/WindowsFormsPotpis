﻿namespace WindowsFormsPotpis
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtPkcs11LibPath;
        private System.Windows.Forms.Button btnSavePath;
        private System.Windows.Forms.Button btnChoosePkcs11Lib;
        private System.Windows.Forms.Button btnRefreshPkcs11Libs;
        private System.Windows.Forms.TextBox txtSelectedFile;
        private System.Windows.Forms.Button btnChooseFile;
        private System.Windows.Forms.Button btnSign;
        private System.Windows.Forms.ComboBox cbPkcs11Libs;
        private System.Windows.Forms.ComboBox cbCertificates; // ComboBox for certificates
        private System.Windows.Forms.Button btnRefreshCertificates;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Button btnChooseSignature;
        private System.Windows.Forms.CheckBox chkTimestamp;
        private System.Windows.Forms.CheckBox chkUsePkcs11;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtPkcs11LibPath = new TextBox();
            btnSavePath = new Button();
            btnChoosePkcs11Lib = new Button();
            btnRefreshPkcs11Libs = new Button();
            txtSelectedFile = new TextBox();
            btnChooseFile = new Button();
            btnSign = new Button();
            cbPkcs11Libs = new ComboBox();
            cbCertificates = new ComboBox();
            btnRefreshCertificates = new Button();
            txtLog = new TextBox();
            btnChooseSignature = new Button();
            chkTimestamp = new CheckBox();
            SuspendLayout();
            // 
            // txtPkcs11LibPath
            // 
            txtPkcs11LibPath.Location = new Point(23, 23);
            txtPkcs11LibPath.Name = "txtPkcs11LibPath";
            txtPkcs11LibPath.Size = new Size(349, 23);
            txtPkcs11LibPath.TabIndex = 0;

            // In the InitializeComponent method
            this.chkUsePkcs11 = new System.Windows.Forms.CheckBox();
            this.chkUsePkcs11.AutoSize = true;
            this.chkUsePkcs11.Location = new System.Drawing.Point(20, 220);  // Adjust the position as needed
            this.chkUsePkcs11.Name = "chkUsePkcs11";
            this.chkUsePkcs11.Size = new System.Drawing.Size(137, 17);
            this.chkUsePkcs11.TabIndex = 10;
            this.chkUsePkcs11.Text = "Koristi PKCS#11 za PIN";
            this.chkUsePkcs11.UseVisualStyleBackColor = true;
            this.Controls.Add(this.chkUsePkcs11);


            // 
            // btnSavePath
            // 
            btnSavePath.Location = new Point(385, 23);
            btnSavePath.Name = "btnSavePath";
            btnSavePath.Size = new Size(88, 27);
            btnSavePath.TabIndex = 1;
            btnSavePath.Text = "Sačuvaj";
            btnSavePath.UseVisualStyleBackColor = true;
            btnSavePath.Click += btnSavePath_Click;
            // 
            // btnChoosePkcs11Lib
            // 
            btnChoosePkcs11Lib.Location = new Point(490, 23);
            btnChoosePkcs11Lib.Name = "btnChoosePkcs11Lib";
            btnChoosePkcs11Lib.Size = new Size(88, 27);
            btnChoosePkcs11Lib.TabIndex = 2;
            btnChoosePkcs11Lib.Text = "Izaberi";
            btnChoosePkcs11Lib.UseVisualStyleBackColor = true;
            btnChoosePkcs11Lib.Click += btnChoosePkcs11Lib_Click;
             // 
            // btnRefreshPkcs11Libs
            // 
            btnRefreshPkcs11Libs.Location = new Point(583, 23);
            btnRefreshPkcs11Libs.Name = "btnRefreshPkcs11Libs";
            btnRefreshPkcs11Libs.Size = new Size(105, 27);
            btnRefreshPkcs11Libs.TabIndex = 3;
            btnRefreshPkcs11Libs.Text = "Osveži lib.";
            btnRefreshPkcs11Libs.UseVisualStyleBackColor = true;
            btnRefreshPkcs11Libs.Click += btnRefreshPkcs11Libs_Click;
            // 
            // txtSelectedFile
            // 
            txtSelectedFile.Location = new Point(23, 140);
            txtSelectedFile.Name = "txtSelectedFile";
            txtSelectedFile.Size = new Size(349, 23);
            txtSelectedFile.TabIndex = 7;
            // 
            // btnChooseFile
            // 
            btnChooseFile.Location = new Point(385, 140);
            btnChooseFile.Name = "btnChooseFile";
            btnChooseFile.Size = new Size(88, 27);
            btnChooseFile.TabIndex = 8;
            btnChooseFile.Text = "Izaberi fajl";
            btnChooseFile.UseVisualStyleBackColor = true;
            btnChooseFile.Click += btnChooseFile_Click;
            // 
            // btnSign
            // 
            btnSign.Location = new Point(490, 140);
            btnSign.Name = "btnSign";
            btnSign.Size = new Size(88, 27);
            btnSign.TabIndex = 9;
            btnSign.Text = "Potpiši";
            btnSign.UseVisualStyleBackColor = true;
            btnSign.Click += btnSign_Click;
            // 
            // cbPkcs11Libs
            // 
            cbPkcs11Libs.Location = new Point(23, 60);
            cbPkcs11Libs.Name = "cbPkcs11Libs";
            cbPkcs11Libs.Size = new Size(790, 23);
            cbPkcs11Libs.TabIndex = 4;
            cbPkcs11Libs.SelectedIndexChanged += cbPkcs11Libs_SelectedIndexChanged;
            // 
            // cbCertificates
            // 
            cbCertificates.Location = new Point(23, 100);
            cbCertificates.Name = "cbCertificates";
            cbCertificates.Size = new Size(790, 23);
            cbCertificates.TabIndex = 5;
            cbCertificates.SelectedIndexChanged += cbCertificates_SelectedIndexChanged;
            // 
            // btnRefreshCertificates
            // 
            btnRefreshCertificates.Location = new Point(708, 23);
            btnRefreshCertificates.Name = "btnRefreshCertificates";
            btnRefreshCertificates.Size = new Size(105, 27);
            btnRefreshCertificates.TabIndex = 6;
            btnRefreshCertificates.Text = "Osveži cert.";
            btnRefreshCertificates.UseVisualStyleBackColor = true;
            btnRefreshCertificates.Click += btnRefreshCertificates_Click;
            // 
            // txtLog
            // 
            txtLog.Location = new Point(839, 26);
            txtLog.Multiline = true;
            txtLog.Name = "txtLog";
            txtLog.Size = new Size(539, 362);
            txtLog.TabIndex = 10;
            // 
            // btnChooseSignature
            // 
            btnChooseSignature.Location = new Point(464, 219);
            btnChooseSignature.Name = "btnChooseSignature";
            btnChooseSignature.Size = new Size(171, 27);
            btnChooseSignature.TabIndex = 11;
            btnChooseSignature.Text = "Izaberi svojerucni potpis";
            btnChooseSignature.UseVisualStyleBackColor = true;
            btnChooseSignature.Click += btnChooseSignature_Click;
            // 
            // chkTimestamp
            // 
            chkTimestamp.Location = new Point(653, 222);
            chkTimestamp.Name = "chkTimestamp";
            chkTimestamp.Size = new Size(120, 24);
            chkTimestamp.TabIndex = 12;
            chkTimestamp.Text = "Dodaj vremensku oznaku";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1424, 400);
            Controls.Add(txtPkcs11LibPath);
            Controls.Add(btnSavePath);
            Controls.Add(btnChoosePkcs11Lib);
            Controls.Add(btnRefreshPkcs11Libs);
            Controls.Add(cbPkcs11Libs);
            Controls.Add(cbCertificates);
            Controls.Add(btnRefreshCertificates);
            Controls.Add(txtSelectedFile);
            Controls.Add(btnChooseFile);
            Controls.Add(btnSign);
            Controls.Add(txtLog);
            Controls.Add(btnChooseSignature);
            Controls.Add(chkTimestamp);
            Name = "Form1";
            Text = "Aplikacija za potpisivanje PDF-a";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}